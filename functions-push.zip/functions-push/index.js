// Облачная функция "В рейсе": при каждом изменении данных пользователя
// рассылает тихий push на все его зарегистрированные устройства — это и
// будит приложение в фоне, без чего мгновенная синхронизация "как в Google
// Keep" невозможна на вебе (см. пояснение в Finish.docx, раздел про push).
//
// Требует Firebase CLI и тариф Blaze (платный, но с щедрым бесплатным
// лимитом — см. Finish.docx). Установка и разворачивание:
//   npm install -g firebase-tools     (один раз)
//   firebase login                    (один раз)
//   cd functions-push && npm install
//   firebase deploy --only functions --project v-reyse

const { onDocumentWritten } = require('firebase-functions/v2/firestore');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore } = require('firebase-admin/firestore');
const { getMessaging } = require('firebase-admin/messaging');

initializeApp();

exports.notifyOnDataChange = onDocumentWritten('users/{uid}', async (event) => {
  const uid = event.params.uid;
  const db = getFirestore();

  // Токены всех устройств, на которых этот пользователь входил в приложение.
  const devicesSnap = await db.collection('users').doc(uid).collection('devices').get();
  if (devicesSnap.empty) return;

  const tokens = devicesSnap.docs.map(d => d.data().token).filter(Boolean);
  if (tokens.length === 0) return;

  // data-message без "notification" — пусть само приложение (через
  // messaging.onMessage / onBackgroundMessage) решает, что показать. Так
  // обычное открытое приложение обновится вообще без всякого уведомления,
  // а свёрнутое — покажет тихий баннер через service worker.
  const message = {
    data: { type: 'data-sync' },
    tokens
  };

  const response = await getMessaging().sendEachForMulticast(message);

  // Токены, которые Firebase считает недействительными (переустановили
  // приложение, отозвали разрешение и т.п.) — чистим, чтобы список устройств
  // не разрастался мусором.
  const staleTokens = [];
  response.responses.forEach((res, i) => {
    if (!res.success) {
      const code = res.error && res.error.code;
      if (code === 'messaging/registration-token-not-registered') {
        staleTokens.push(tokens[i]);
      }
    }
  });
  await Promise.all(
    staleTokens.map(token =>
      db.collection('users').doc(uid).collection('devices').doc(token).delete().catch(() => {})
    )
  );
});
